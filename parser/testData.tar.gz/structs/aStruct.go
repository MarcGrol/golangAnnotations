package structs

type YetAnotherStruct struct {
	Y int
}

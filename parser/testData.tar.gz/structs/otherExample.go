package structs

import "github.com/MarcGrol/golangAnnotations/parser/structs/substruct"

type OtherStruct struct {
	Y  int
	sA substruct.StructSub
}

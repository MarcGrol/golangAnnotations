package substruct

type StructSub struct {
	Name string
}
